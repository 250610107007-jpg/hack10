# 🧭 CampusCompass GECP (2026–27)
**Government Engineering College, Palanpur • Smart Timetable & 3D Campus GPS Navigator**

---

## 🚀 How to Run & Share the App

### Option 1: Standalone Portable ZIP (.zip) — Share with Friends!
- A ready-to-run package **`CampusCompass_GECP.zip`** is included in the project directory!
- You can send this ZIP to anyone via WhatsApp, Telegram, Pendrive, or Google Drive.
- Anyone receiving it just needs to extract the ZIP and **double-click `run_app.bat`** (or `Launch_App.vbs` for silent mode). It launches immediately without complicated setup!

### Option 2: Native Windows Desktop App (One-Click)
- **Double-click `run_app.bat`** in this folder.
- Launches the Python backend and opens the portal as a native desktop application with custom icon and no browser address bar.

### Option 3: Share Over Campus Wi-Fi / Hotspot (Instant Mobile Access)
- Run `python app.py` or start the app.
- Click **"📲 Download & Share App"** in the top navigation bar.
- Anyone connected to the same college Wi-Fi can scan the **QR Code** or open `http://<YOUR-IP>:5000` to access the full app immediately on their Android, iPhone, or laptop!

### Option 4: Install as Device App (PWA)
- Click **"📲 Install as Device App"** to add an app icon directly to your desktop or mobile home screen.

---

## 🛠️ Problems Resolved & Enhancements

1. **Backend Dependencies & Installation**:
   - Installed `flask`, `flask-cors`, `pywebview`, and `pillow`.
2. **Backend & Frontend Full Connection**:
   - Integrated `app.py` with Flask-CORS to eliminate cross-origin blocks.
   - Connected student registration and student login directly to the SQLite backend (`/api/students/register` and `/api/students/login`).
   - Connected faculty registration and login directly to backend (`/api/faculty/register` and `/api/faculty/login`).
   - Connected admin timetable management (Add, Edit, Delete) directly to SQLite (`/api/timetable`).
   - Connected admin student management (View, Edit, Delete, Total count) to `/api/students`.
   - Connected private class notes and assignment submissions to backend (`/api/notes` and `/api/submissions`).
3. **Database Seeding**:
   - Populated `database.db` with all 483 college timetable classes across Civil, Electrical, Mechanical, and Computer Engineering departments.
   - Safely preserved all 7 existing student accounts.
4. **Bug Fixes in Frontend JavaScript (`app.js`)**:
   - Fixed broken student login ID references (`sLoginEnroll` -> `loginId`, `sLoginPass` -> `loginPass`).
   - Fixed missing `refreshData()` function that previously caused runtime errors.
   - Consolidated confusing duplicate files (`app (1).js` backed up).
5. **Preserved Website Design & Background**:
   - All original styles, colors, and background themes (`--light: #f4faf7`, header gradient `#0f5134 -> #249463`, card backgrounds) were **100% preserved**.
6. **Campus Wayfinding Maps**:
   - Created high-resolution floor-plan diagrams for 8000, 4000, 5000, and 7000 series blocks in `maps/` so "View Map" buttons show actual layouts instead of broken images.
7. **Converted into App**:
   - Added `desktop_app.py` with `pywebview` and Windows Edge App fallback.
   - Added `manifest.json`, `sw.js` (service worker), app icons (`icon-192.png`, `icon-512.png`, `app_icon.ico`).
   - Added `run_app.bat` and `Launch_App.vbs`.

---

## 🔐 Credentials & Demo Logins

### Department Admin Passwords:
- **Computer Engineering**: `computer123`
- **Electrical Engineering**: `electrical123`
- **Civil Engineering**: `civil123`
- **Mechanical Engineering**: `mechanical123`

### Student Accounts:
- Students can log in using either their **Enrollment Number** or **10-digit Mobile Number**.
- New students can register instantly via the **"New Student Sign Up"** tab.

### Faculty Accounts:
- Faculty members can log in using their **Faculty Code** (e.g. `SDJ`, `RHJ`, `KMG`, `RS`, `PGV`, etc.) or email.
- Default password for pre-seeded faculty accounts: `faculty123`.
- Any existing faculty can also set a new password via the **"Faculty Sign Up"** tab to activate/update their account.

---

## 🗺️ Campus GPS & Google Maps Wayfinding System
- **Real-Time GPS Tracking**: Click **"Detect My GPS"** or select **"📍 My Live GPS Location"** to detect your device coordinates.
- **Start to Destination Routing**: Choose any origin (Main Gate, Canteen, Library, Admin Block, or Live Location) and destination classroom/lab (e.g. Room 5104, Room 4010, Workshop, CAD/CAM Lab).
- **Google Maps Navigation View**: Shows distance in meters, estimated walking time in minutes, turn-by-turn directions cards, and an animated SVG walking route path.
- **Official College 3D Maps**: Incorporates high-resolution satellite imagery and official 3D architectural floor plans for the Mechanical Engineering (5000/5100 series) and Electrical Engineering (4000/4100 series) blocks.
- **Direct Timetable Navigation**: Click the **"🧭 Navigate"** button directly on any class schedule card in the timetable or student/faculty dashboard to instantly calculate walking directions to that room.

---

## 🗄️ In-App Database Explorer
- Accessible directly from the top navigation bar by clicking **"🗄️ Database"**.
- Displays real-time database health, file size, and total record counts across all SQLite tables (`students`, `faculty`, `timetable`, `notes`, `submissions`).
- Interactive table tabs allow browsing full records with real-time search filtering and secure password hashing.
